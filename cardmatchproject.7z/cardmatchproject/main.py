from flask import Flask, render_template, jsonify, request
import uuid
from google.cloud import datastore

app = Flask(__name__)
datastore_client = datastore.Client(project="cardmatchproject")

def customer_exists(email_id):
    query = datastore_client.query(kind='customer')
    query.add_filter("email", '=', email_id)
    results = list(query.fetch())
    if len(results) > 0:
        return results[0]
    else:
        return False


@app.route('/addCard', methods=['POST'])
def add_card_details():
    card_json = request.json
    try:
        customerDetails = card_json["customer"]
        if "email" not in customerDetails.keys() or customerDetails["email"]  == '':
            return jsonify("Customer email missing")
    except Exception:
        return jsonify("Customer data missing")

    try:
        cardDetails = card_json["cardDetails"]
    except Exception:
        return jsonify("Card Details missing")

    #Check if the customer does not exist currently. If not, then create a new customer.
    cust_exists= customer_exists(customerDetails["email"])
    if cust_exists:
        customer_key = cust_exists.key.path[0]["name"]
    else:
        customer_key = str(uuid.uuid4())

    customer_entity = datastore.Entity(key=datastore_client.key('customer', customer_key))
    cardDetails["customerID"] = customer_key
    card_entity = datastore.Entity(key=datastore_client.key('card_details'))

    customer_entity.update((customerDetails))
    card_entity.update(cardDetails)
    datastore_client.put(card_entity)
    datastore_client.put(customer_entity)
    return jsonify("Success")


def get_customer_details(customer_ids):
    id_list = []
    for customer_id in customer_ids:
        print(customer_id)
        customer_key = datastore_client.key('customer', customer_id)
        query = datastore_client.query(kind='customer')
        query.key_filter(customer_key, '=')
        results = list(query.fetch())
        if len(results) > 0:
            id_list.append(results[0]['email'])
    return id_list


@app.route('/getCard')
def get_card_details():
    card_json = request.json
    query = datastore_client.query(kind='card_details')
    for key, value in card_json.items():
        query.add_filter(key, '=', value)
    results = [result['customerID'] for result in query.fetch()]

    if len(results)>0:
        return jsonify(get_customer_details(results))

    #Try to get the best matches
    all_results = []
    for key, value in card_json.items():
        query = datastore_client.query(kind='card_details')
        query.add_filter(key, '=', value)
        results = set([result['customerID'] for result in query.fetch()])
        all_results.append(results)
    all_results.sort(key=len, reverse=True)
    intersect_results = set.intersection(*all_results)
    if len(list(intersect_results)) > 0:
        return jsonify(get_customer_details(list(all_results)))

    #Get all possible values
    all_results = [item for sublist in all_results for item in sublist]
    return jsonify(get_customer_details(list(set(all_results))))




@app.route('/')
def root():
    return jsonify([])


if __name__ == '__main__':
    app.run(host='127.0.0.1', port=8080, debug=True)
